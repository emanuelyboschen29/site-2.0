add as extensões e tals com npm install -g nodemon
colocar o ENV
e importar o DB com o SGBD Mysql.
"# rafa_joias" 
