document.addEventListener("DOMContentLoaded", () => {
  const produto = JSON.parse(localStorage.getItem("produtoSelecionado"));

  if (!produto) {
    alert("Produto não encontrado!");
    window.location.href = "/html/main.html";
    return;
  }

  // Preenche os dados
  document.getElementById("imagem-produto").src = produto.img;
  document.getElementById("nome-produto").textContent = produto.nome;
  document.getElementById("preco-produto").textContent = `R$ ${produto.preco},00`;
  document.getElementById("descricao-produto").textContent = produto.descricao || "Produto elegante, perfeito para seu estilo.";

  // Funções de carrinho
  function obterCarrinho() {
    try {
      return JSON.parse(localStorage.getItem("carrinho")) || [];
    } catch {
      return [];
    }
  }

  function salvarCarrinho(carrinho) {
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
  }

  function mostrarNotificacao(mensagem) {
    const notif = document.createElement("div");
    notif.textContent = mensagem;
    Object.assign(notif.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      background: "linear-gradient(135deg, #4b3b2b, #a67c52)",
      color: "#fff",
      padding: "12px 18px",
      borderRadius: "8px",
      fontWeight: "500",
      zIndex: "9999",
      transition: "opacity 0.4s",
      opacity: "0",
    });
    document.body.appendChild(notif);
    requestAnimationFrame(() => notif.style.opacity = "1");
    setTimeout(() => {
      notif.style.opacity = "0";
      setTimeout(() => notif.remove(), 400);
    }, 2000);
  }

  // Botão adicionar ao carrinho
  document.getElementById("btn-add-carrinho").addEventListener("click", () => {
    const carrinho = obterCarrinho();
    carrinho.push({
      nome: produto.nome,
      preco: produto.preco,
      img: produto.img,
      descricao: produto.descricao,
      qtd: 1
    });
    salvarCarrinho(carrinho);
    mostrarNotificacao(`🛒 ${produto.nome} foi adicionado ao carrinho!`);
  });
});
